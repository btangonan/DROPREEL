# DropReel MVP

DropReel is a web application that turns a Dropbox folder containing multiple video files into a sleek, interactive video reel, similar to Wiredrive's presentation reels.

## Features

- Retrieves and lists video files from a specified Dropbox folder
- Generates temporary Dropbox streaming links for smooth video playback
- Displays videos in a clean, responsive, interactive player
- Simple navigation controls (forward, back, play/pause)
- Drag-and-drop interface for video reordering
- Public sharing via unique URLs

## Tech Stack

- **Frontend**: Next.js with TypeScript and Tailwind CSS
- **Video Player**: Plyr.js for a clean, customizable player
- **Dropbox Integration**: Dropbox API v2
- **Deployment**: Ready for Vercel or Netlify

## Getting Started

### Prerequisites

- Node.js 16.x or higher
- A Dropbox account with API access
- A folder in your Dropbox containing video files

### Setting Up a Dropbox App

1. Go to [Dropbox App Console](https://www.dropbox.com/developers/apps)
2. Click "Create App"
3. Select "Scoped access API"
4. Choose "Full Dropbox" access
5. Name your app (e.g., "DropReel")
6. In the app settings, find and generate an access token

### Installation

1. Clone the repository
2. Install dependencies:

```bash
npm install
```

3. Copy `env.example` to `.env.local` and set your Dropbox credentials:

```
DROPBOX_ACCESS_TOKEN=your_access_token_here
DROPBOX_FOLDER_PATH=/path/to/your/videos/folder
```

4. Run the development server:

```bash
npm run dev
```

5. Open [http://localhost:3000](http://localhost:3000) in your browser

## Using DropReel

1. **Create a Reel**: The home page allows you to view videos from your Dropbox folder, reorder them via drag-and-drop, and create a shareable reel.

2. **Share the URL**: After creating a reel, you'll get a unique URL (e.g., `http://yourdomain.com/r/abcd1234`) that you can share with others.

3. **Public Viewing**: Anyone with the link can view the reel without needing to log in.

## Development Notes

- Temporary streaming links from Dropbox expire after about 4 hours. The application handles refreshing these links when needed.
- The application uses a simple file-based storage system for the MVP. For production use, consider integrating a more robust database solution.

## Future Enhancements (Phase 2)

- User authentication via Dropbox OAuth 2.0
- Customizable video thumbnails
- Viewer analytics
- Video download options
- Enhanced UI customization and branding
