# DropReel Setup & Context

## What is DropReel?
DropReel is a modern web application for building video reels from Dropbox videos. Users can browse their Dropbox folders, select video files, and assemble a custom reel by dragging and dropping video thumbnails between two main panels: **YOUR VIDEOS** and **SELECTS**. The app is designed for a fast, intuitive, and robust video curation experience.

## Tech Stack
- **Framework:** Next.js (React, TypeScript)
- **DnD Library:** dnd-kit (`@dnd-kit/core`, `@dnd-kit/sortable`)
- **Cloud Storage:** Dropbox API (OAuth, file/folder browsing, video streaming)
- **Styling:** Tailwind CSS

## Setup Instructions

### 1. Unzip or Clone the Project
If you have a zip file:
```sh
unzip dropreel-mvp-full-backup.zip
cd dropreel-mvp
```
If you cloned from git:
```sh
git clone <repo-url>
cd dropreel-mvp
```

### 2. Install Dependencies
```sh
npm install
```

### 3. Configure Environment Variables
- Copy `env.example` to `.env.local`:
  ```sh
  cp env.example .env.local
  ```
- Fill in your Dropbox API keys and any other required secrets in `.env.local`.

### 4. Run the App
```sh
npm run dev
```
- The app will start on [http://localhost:3000](http://localhost:3000).

### 5. Where to Find Key Files
- **Main App Logic:** `src/app/page.tsx`
- **DnD Grid Component:** `src/components/DraggableVideoList/DndKitVideoGrid.tsx`
- **Dropbox API Logic:** `src/lib/dropboxFetch.ts`
- **Project Audit/Docs:** `DROPREEL_PROJECT_AUDIT.md`, `DROPREEL_SETUP_AND_CONTEXT.md`

## Special Notes
- **No node_modules in zip:** You must run `npm install` after unzipping.
- **No Dropbox credentials included:** You must provide your own Dropbox API keys in `.env.local`.
- **All code, assets, and documentation are included in the zip for a full restore.**

---

_Last updated: 2024-06-09_ 