import React from 'react';
import {
  DndContext,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
  DragOverlay,
  useDroppable,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  useSortable,
  rectSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { VideoFile } from '@/types';

interface DndKitVideoGridProps {
  videos: VideoFile[];
  onReorder: (videos: VideoFile[]) => void;
  gridId: string;
  onVideoClick?: (video: VideoFile) => void;
  emptyMessage?: string;
}

function VideoGridItem({ video, listeners, attributes, isDragging, onClick, style }: any) {
  return (
    <div
      className={`w-full flex flex-col items-center cursor-pointer transition-colors ${isDragging ? 'z-50' : ''}`}
      style={{ borderRadius: '0.5rem', padding: 0, ...style }}
      tabIndex={0}
      onClick={onClick}
      {...attributes}
      {...listeners}
    >
      <div className={`relative w-full aspect-video bg-gray-200 rounded overflow-hidden border-2 ${isDragging ? 'shadow-lg border-blue-400 bg-blue-50' : 'border-gray-400 bg-white'}`}
        style={{ transition: 'none' }}>
        {video.thumbnailUrl ? (
          <>
            <img
              src={video.thumbnailUrl}
              alt={video.name}
              className="w-full h-full object-cover rounded"
              style={{ transition: 'none' }}
              onError={e => {
                (e.target as HTMLImageElement).style.display = 'none';
              }}
              loading="lazy"
            />
            <div className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 bg-black bg-opacity-30 transition-opacity">
              <span className="text-white text-xs">▶ Play</span>
            </div>
          </>
        ) : (
          <div className="flex items-center justify-center h-full w-full">
            <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"></path>
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
          </div>
        )}
      </div>
      <div className="truncate text-xs text-center mt-1 w-full" title={video.name}>{video.name}</div>
    </div>
  );
}

function SortableVideoGridItem({ video, onClick }: any) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: video.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div ref={setNodeRef} style={style} className="w-full">
      <VideoGridItem
        video={video}
        listeners={listeners}
        attributes={attributes}
        isDragging={isDragging}
        onClick={() => onClick?.(video)}
      />
    </div>
  );
}

function EmptyDropZone({ gridId, isOver, children }: { gridId: string; isOver: boolean; children: React.ReactNode }) {
  return (
    <div
      className={`flex items-center justify-center h-32 w-full col-span-full border-2 border-dashed rounded-lg transition-colors ${isOver ? 'border-blue-400 bg-blue-50' : 'border-gray-300 bg-gray-100'}`}
      style={{ minHeight: '6rem' }}
    >
      {children}
    </div>
  );
}

export default function DndKitVideoGrid({ videos, onReorder, gridId, onVideoClick, emptyMessage }: DndKitVideoGridProps) {
  const [activeId, setActiveId] = React.useState<string | null>(null);
  const { isOver, setNodeRef } = useDroppable({ id: gridId });
  // Debug output for gridId, video count, and IDs
  const itemIds = videos.map(v => v.id);
  console.log(`[DndKitVideoGrid] gridId: ${gridId}, video count: ${videos.length}, IDs:`, itemIds);

  return (
    <div ref={setNodeRef} className="w-full">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 min-h-[100px]">
        {videos.length === 0 ? (
          <EmptyDropZone gridId={gridId} isOver={isOver}>
            {emptyMessage}
          </EmptyDropZone>
        ) : (
          videos.map(video => (
            <SortableVideoGridItem key={video.id} video={video} onClick={onVideoClick} />
          ))
        )}
      </div>
    </div>
  );
} 