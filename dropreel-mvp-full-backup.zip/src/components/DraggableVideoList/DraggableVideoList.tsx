'use client';

import React, { useState, useEffect } from 'react';
import { VideoFile } from '@/types';
import { Droppable, Draggable } from 'react-beautiful-dnd';

// Helper function to format file size
const formatFileSize = (bytes?: number): string => {
  if (!bytes) return '';
  
  const units = ['B', 'KB', 'MB', 'GB'];
  let size = bytes;
  let unitIndex = 0;
  
  while (size >= 1024 && unitIndex < units.length - 1) {
    size /= 1024;
    unitIndex++;
  }
  
  return `${size.toFixed(1)} ${units[unitIndex]}`;
};

interface DraggableVideoListProps {
  droppableId: string;
  videos: VideoFile[];
  currentVideo?: VideoFile;
  selectedVideos?: string[];
  onVideoSelect: (video: VideoFile) => void;
  showCheckboxes?: boolean;
  title?: string;
  emptyMessage?: string;
}

export default function DraggableVideoList({
  droppableId,
  videos,
  currentVideo,
  selectedVideos = [],
  onVideoSelect,
  showCheckboxes = true,
  title,
  emptyMessage = 'No videos available.'
}: DraggableVideoListProps) {
  
  // Accessibility enhancement: keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent, video: VideoFile) => {
    // Select item with Enter or Space
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      onVideoSelect(video);
    }
  };
  
  return (
    // We now only use Droppable directly, no need for StrictModeDroppable here
    // This component is used with the parent's DragDropContext
    <Droppable droppableId={droppableId} isDropDisabled={false} isCombineEnabled={false} ignoreContainerClipping={true}>
      {(provided, snapshot) => (
        <div
          ref={provided.innerRef}
          {...provided.droppableProps}
          className={`w-full min-h-[100px] p-2 rounded-lg ${snapshot.isDraggingOver ? 'bg-blue-50' : ''}`}
          aria-label={title || 'Video List'}
        >
          {/* Grid container for thumbnails */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {title && (
              <h3 className="font-medium text-lg mb-3">{title}</h3>
            )}
            {videos.length === 0 ? (
              <div className="flex items-center justify-center h-32 text-gray-500 w-full">
                {emptyMessage}
              </div>
            ) : (
              <>
                {videos.map((video, index) => (
                  <Draggable
                    key={video.id}
                    draggableId={video.id}
                    index={index}
                  >
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        {...provided.dragHandleProps}
                        className={`w-full flex flex-col items-center cursor-pointer transition-colors ${snapshot.isDragging ? 'shadow-lg opacity-70' : ''}`}
                        onClick={() => onVideoSelect(video)}
                        onKeyDown={(e) => handleKeyDown(e, video)}
                        tabIndex={0}
                        aria-selected={currentVideo?.id === video.id}
                        role="option"
                        style={{ background: 'none', borderRadius: '0.5rem', padding: 0 }}
                      >
                        <div className="relative w-full aspect-video bg-gray-200 rounded overflow-hidden">
                          {video.thumbnailUrl ? (
                            <>
                              <img
                                src={video.thumbnailUrl}
                                alt={video.name}
                                className="w-full h-full object-cover rounded"
                                onError={(e) => {
                                  (e.target as HTMLImageElement).style.display = 'none';
                                }}
                                loading="lazy"
                              />
                              <div className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 bg-black bg-opacity-30 transition-opacity">
                                <span className="text-white text-xs">▶ Play</span>
                              </div>
                            </>
                          ) : (
                            <div className="flex items-center justify-center h-full w-full">
                              <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"></path>
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                              </svg>
                            </div>
                          )}
                        </div>
                        <div className="truncate text-xs text-center mt-1 w-full" title={video.name}>{video.name}</div>
                      </div>
                    )}
                  </Draggable>
                ))}
              </>
            )}
          </div>
          {provided.placeholder}
        </div>
      )}
    </Droppable>
  );
}
