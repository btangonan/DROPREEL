'use client';

import React, { useState, useEffect } from 'react';

interface DropboxAuthProps {
  onAuthChange?: (isAuthenticated: boolean) => void;
  highlight?: boolean;
  state?: 'next' | 'complete' | 'default';
}

const DropboxAuth: React.FC<DropboxAuthProps> = ({ onAuthChange, highlight, state }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Check authentication status on component mount
  useEffect(() => {
    const checkAuth = async () => {
      try {
        // Check if we have the auth cookie
        const hasAuthCookie = document.cookie.includes('dropbox_auth_success=true');
        
        // Make API call to check if we have valid credentials
        const response = await fetch('/api/auth/dropbox/status');
        const data = await response.json();
        
        setIsAuthenticated(data.isAuthenticated || hasAuthCookie);
        if (onAuthChange) onAuthChange(data.isAuthenticated || hasAuthCookie);
      } catch (error) {
        console.error('Error checking auth status:', error);
        setIsAuthenticated(false);
        if (onAuthChange) onAuthChange(false);
      } finally {
        setIsLoading(false);
      }
    };
    
    checkAuth();
  }, []);

  // Notify parent on auth status change
  useEffect(() => {
    if (onAuthChange) onAuthChange(isAuthenticated);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated]);

  const handleAuth = () => {
    // Redirect to the auth endpoint
    window.location.href = '/api/auth/dropbox';
  };

  const handleRefresh = () => {
    // Force a token refresh
    fetch('/api/auth/dropbox/refresh')
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          alert('Token refreshed successfully!');
        } else {
          alert('Failed to refresh token. Please re-authenticate.');
          setIsAuthenticated(false);
        }
      })
      .catch(error => {
        console.error('Error refreshing token:', error);
        alert('Error refreshing token. Please try again.');
      });
  };

  if (isLoading) {
    return <div className="text-center p-4">Checking authentication status...</div>;
  }

  return (
    <div className="w-full h-full flex items-center justify-center">
      {isAuthenticated ? (
        <div
          className={`w-full h-full flex items-center justify-center rounded-lg font-black text-xl md:text-2xl min-h-[64px] md:h-24 text-center select-none opacity-100 text-white
            ${state === 'complete' ? 'bg-green-400' : state === 'next' ? 'bg-yellow-300 text-yellow-900 animate-pulse' : 'bg-gray-300'}`}
        >
          CONNECTED
        </div>
      ) : (
        <button
          onClick={handleAuth}
          className={`w-full h-full flex items-center justify-center rounded-lg font-black text-xl md:text-2xl min-h-[64px] md:h-24 text-center transition-all focus:outline-none
            ${state === 'next' ? 'bg-yellow-300 text-yellow-900 animate-pulse' : state === 'complete' ? 'bg-green-400 text-white' : 'bg-gray-300 text-gray-700'}
            ${highlight ? 'ring-4 ring-blue-400 ring-opacity-60 shadow-lg scale-105' : ''} hover:bg-blue-200`}
          style={highlight ? { boxShadow: '0 0 0 4px #60a5fa55, 0 4px 20px #60a5fa33' } : {}}
        >
          CONNECT TO DROPBOX
        </button>
      )}
    </div>
  );
};

export default DropboxAuth;
