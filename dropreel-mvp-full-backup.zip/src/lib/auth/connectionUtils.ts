import { Dropbox } from 'dropbox';
import fetch from 'node-fetch';
import fs from 'fs';
import path from 'path';
import { getValidAccessToken } from './dropboxAuth';

const TOKEN_PATH = path.join(process.cwd(), '.credentials', 'dropbox_token.json');

/**
 * Tests the Dropbox connection by attempting to access account info
 * Returns detailed status information about the connection
 */
export const testDropboxConnection = async (): Promise<{
  connected: boolean;
  status: string;
  details: {
    tokenExists: boolean;
    tokenAge?: number; // in minutes
    tokenExpiry?: string;
    refreshTokenExists?: boolean;
    accountInfo?: any;
    error?: any;
  }
}> => {
  try {
    // Define a complete type for details to resolve TypeScript lint errors
    const result = {
      connected: false,
      status: 'unknown',
      details: {
        tokenExists: false,
        tokenAge: undefined as number | undefined,
        tokenExpiry: undefined as string | undefined,
        refreshTokenExists: undefined as boolean | undefined,
        accountInfo: undefined as any,
        error: undefined as any
      }
    };
    
    // Check if token file exists
    if (!fs.existsSync(TOKEN_PATH)) {
      return {
        ...result,
        status: 'no_credentials'
      };
    }
    
    // Read token data
    const tokenData = JSON.parse(fs.readFileSync(TOKEN_PATH, 'utf8'));
    result.details.tokenExists = true;
    
    // Check token age
    if (tokenData.expires_at) {
      try {
        const expiryTimestamp = typeof tokenData.expires_at === 'string' 
          ? new Date(tokenData.expires_at).getTime()
          : tokenData.expires_at;
            
        const expiryDate = new Date(expiryTimestamp);
        result.details.tokenExpiry = expiryDate.toISOString();
        
        const now = Date.now();
        // Token duration is typically 4 hours, so calculate age based on that
        const tokenDuration = 4 * 60 * 60 * 1000; // 4 hours in ms
        const ageInMs = Math.max(0, now - (expiryTimestamp - tokenDuration));
        result.details.tokenAge = Math.floor(ageInMs / (1000 * 60)); // convert to minutes
      } catch (err) {
        console.error('Error calculating token age:', err);
        // Don't let this error prevent the rest of the checks
      }
    }
    
    // Check if refresh token exists
    result.details.refreshTokenExists = !!tokenData.refresh_token;
    
    // Try to get a valid access token (this will refresh if needed)
    const accessToken = await getValidAccessToken();
    
    if (!accessToken) {
      return {
        ...result,
        status: 'invalid_token'
      };
    }
    
    // Test the token by making an API call
    const dbx = new Dropbox({ 
      accessToken,
      fetch: fetch as any 
    });
    
    // Try to get account info
    const accountInfo = await dbx.usersGetCurrentAccount();
    
    // If we got here, the connection is working
    return {
      connected: true,
      status: 'connected',
      details: {
        ...result.details,
        accountInfo: accountInfo.result
      }
    };
    
  } catch (error) {
    // Determine what kind of error we're dealing with
    let status = 'unknown_error';
    
    if (error instanceof Error) {
      const message = error.message.toLowerCase();
      if (message.includes('network') || message.includes('timeout')) {
        status = 'network_error';
      } else if (message.includes('unauthorized') || message.includes('invalid_token')) {
        status = 'unauthorized';
      }
    }
    
    return {
      connected: false,
      status,
      details: {
        tokenExists: fs.existsSync(TOKEN_PATH),
        error
      }
    };
  }
};

/**
 * Reset the Dropbox connection by deleting the token file
 */
export const resetDropboxConnection = (): { success: boolean; message: string } => {
  try {
    if (fs.existsSync(TOKEN_PATH)) {
      fs.unlinkSync(TOKEN_PATH);
      return { 
        success: true, 
        message: 'Dropbox connection reset successfully' 
      };
    }
    return { 
      success: false, 
      message: 'No Dropbox connection to reset' 
    };
  } catch (error) {
    return { 
      success: false, 
      message: `Failed to reset Dropbox connection: ${error instanceof Error ? error.message : String(error)}` 
    };
  }
};

/**
 * Perform a basic API call to test if Dropbox API is available
 */
export const pingDropboxAPI = async (): Promise<{ available: boolean; latency?: number; status?: number }> => {
  const startTime = Date.now();
  try {
    // Test the Dropbox API availability with a HEAD request to the main API endpoint
    // This is better than calling a specific API endpoint that might require auth
    const response = await fetch('https://api.dropboxapi.com/2', {
      method: 'HEAD',
      // Add a timeout to prevent hanging on network issues
      signal: AbortSignal.timeout(5000) // 5 second timeout
    });
    
    const endTime = Date.now();
    
    return {
      available: response.ok || (response.status >= 400 && response.status < 500),
      latency: endTime - startTime,
      status: response.status
    };
  } catch (error) {
    console.warn('Error checking Dropbox API availability:', 
      error instanceof Error ? error.message : String(error));
    return {
      available: false,
      status: error instanceof DOMException && error.name === 'TimeoutError' ? 408 : undefined,
      latency: Date.now() - startTime // Add latency for failures too
    };
  }
};
