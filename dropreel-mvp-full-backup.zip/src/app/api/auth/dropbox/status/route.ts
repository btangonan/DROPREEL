import { NextRequest, NextResponse } from 'next/server';
import { hasCredentials } from '@/lib/auth/dropboxAuth';

export async function GET(request: NextRequest) {
  try {
    // Check if we have stored credentials
    const isAuthenticated = hasCredentials();
    
    return NextResponse.json({ isAuthenticated });
  } catch (error) {
    console.error('Error checking auth status:', error);
    return NextResponse.json({ isAuthenticated: false });
  }
}
