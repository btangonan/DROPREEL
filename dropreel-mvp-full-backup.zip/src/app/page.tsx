'use client';

import { useState, useEffect, useCallback } from 'react';
import { VideoFile, VideoReel } from '@/types';
import VideoPlayer from '@/components/VideoPlayer/VideoPlayer';
import VideoList from '@/components/VideoList/VideoList';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { extractDropboxPath } from '@/lib/utils/dropboxUtils';
import FolderBrowser from '@/components/FolderBrowser/FolderBrowser';
import DropboxAuth from '@/components/DropboxAuth/DropboxAuth';
import {
  DndContext,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
  DragOverlay,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  rectSortingStrategy,
} from '@dnd-kit/sortable';
import DndKitVideoGrid from '@/components/DraggableVideoList/DndKitVideoGrid';

export default function Home() {
  const [isDropboxAuthenticated, setIsDropboxAuthenticated] = useState(false);
  const [showFolderBrowser, setShowFolderBrowser] = useState(false);
  const [folderPath, setFolderPath] = useState('');
  const [isFetchingVideos, setIsFetchingVideos] = useState(false);
  const [loadedVideos, setLoadedVideos] = useState<VideoFile[]>([]);
  const [error, setError] = useState('');

  // DnD state
  const [videoState, setVideoState] = useState<{ yourVideos: VideoFile[]; selects: VideoFile[] }>({ yourVideos: [], selects: [] });
  const [activeId, setActiveId] = useState<string | null>(null);
  const sensors = useSensors(useSensor(PointerSensor));

  // Centralized user flow state
  type Step = 'connect' | 'addVideos' | 'addTitle';
  let currentStep: Step = 'connect';
  if (isDropboxAuthenticated && !loadedVideos.length) {
    currentStep = 'addVideos';
  } else if (isDropboxAuthenticated && loadedVideos.length) {
    currentStep = 'addTitle';
  }
  const getStepStatus = (step: Step) => {
    if (step === currentStep) return 'next';
    if (
      (step === 'connect' && (currentStep === 'addVideos' || currentStep === 'addTitle')) ||
      (step === 'addVideos' && currentStep === 'addTitle')
    ) return 'complete';
    return 'default';
  };

  const handleAddVideosClick = () => {
    if (isDropboxAuthenticated) setShowFolderBrowser(true);
  };

  const fetchVideos = async (path: string) => {
    if (!path) {
      setError('Please enter a Dropbox folder path or link');
      return;
    }
    setIsFetchingVideos(true);
    setError('');
    try {
      const finalPath = extractDropboxPath(path);
      const response = await fetch(`/api/dropbox?action=listVideos&folderPath=${encodeURIComponent(finalPath)}`);
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error(`Folder "${finalPath}" not found in Dropbox`);
        }
        throw new Error('Failed to load videos');
      }
      const data = await response.json();
      if (data.videos && data.videos.length > 0) {
        const videosWithUrls = await Promise.all(
          data.videos.map(async (video: VideoFile) => {
            const streamResponse = await fetch(`/api/dropbox?action=getStreamUrl&path=${encodeURIComponent(video.path)}`);
            const streamData = await streamResponse.json();
            const thumbnailUrl = `/api/dropbox/thumbnail?path=${encodeURIComponent(video.path)}`;
            return {
              ...video,
              streamUrl: streamData.url,
              thumbnailUrl
            };
          })
        );
        setLoadedVideos(videosWithUrls);
      } else {
        setLoadedVideos([]);
        setError('No video files found in the specified folder');
      }
    } catch (err: any) {
      setError(`Error loading videos: ${err.message}`);
      setLoadedVideos([]);
    } finally {
      setIsFetchingVideos(false);
    }
  };

  // When loadedVideos changes, put all videos in yourVideos and clear selects
  useEffect(() => {
    setVideoState({ yourVideos: loadedVideos, selects: [] });
  }, [loadedVideos]);

  // Helper to find a video by id and which list it's in
  const findVideoById = (id: string) => {
    const inYourVideos = videoState.yourVideos.findIndex(v => v.id === id);
    if (inYourVideos !== -1) return { list: 'yourVideos', index: inYourVideos };
    const inSelects = videoState.selects.findIndex(v => v.id === id);
    if (inSelects !== -1) return { list: 'selects', index: inSelects };
    return null;
  };

  // Helper to check for duplicate IDs
  function logArrayIds(label: string, arr: VideoFile[]) {
    const ids = arr.map((v: VideoFile) => v.id);
    const uniqueIds = new Set(ids);
    if (ids.length !== uniqueIds.size) {
      console.warn(`[${label}] Duplicate IDs detected:`, ids);
    }
    console.log(`[${label}] IDs:`, ids);
    console.log(`[${label}] Length:`, arr.length);
  }

  // Handler for drag end (cross-panel and reorder)
  const handleDragEnd = useCallback((e: any) => {
    setActiveId(null);
    const { active, over } = e;
    if (!active || !over) return;

    setVideoState(prev => {
      // Helper to get array by container name
      const getArray = (state: { yourVideos: VideoFile[]; selects: VideoFile[] }, key: 'yourVideos' | 'selects') =>
        key === 'yourVideos' ? state.yourVideos : state.selects;
      const setArray = (state: { yourVideos: VideoFile[]; selects: VideoFile[] }, key: 'yourVideos' | 'selects', arr: VideoFile[]) => {
        return key === 'yourVideos'
          ? { ...state, yourVideos: arr }
          : { ...state, selects: arr };
      };

      let newState = { yourVideos: [...prev.yourVideos], selects: [...prev.selects] };

      const sourceId = active.id;
      let sourceContainer: 'yourVideos' | 'selects' = 'yourVideos';
      let sourceIndex = newState.yourVideos.findIndex(v => v.id === sourceId);
      if (sourceIndex === -1) {
        sourceContainer = 'selects';
        sourceIndex = newState.selects.findIndex(v => v.id === sourceId);
      }

      // If dropped on a container, append to end
      let destContainer: 'yourVideos' | 'selects' | null = null;
      let destIndex: number = -1;
      if (over.id === 'yourVideos' || over.id === 'selects') {
        destContainer = over.id;
        destIndex = newState[destContainer].length;
      } else {
        // Dropped on an item
        destContainer = newState.yourVideos.find(v => v.id === over.id) ? 'yourVideos' : 'selects';
        destIndex = newState[destContainer].findIndex(v => v.id === over.id);
      }

      // Guard: only proceed if destContainer is valid
      if (!destContainer) return newState;

      if (sourceContainer === destContainer) {
        // Reorder within same container
        const reordered = arrayMove(
          getArray(newState, sourceContainer),
          sourceIndex,
          destIndex
        );
        newState = setArray(newState, sourceContainer, reordered);
      } else {
        // Move between containers
        const sourceArr = [...getArray(newState, sourceContainer)];
        const destArr = [...getArray(newState, destContainer)];
        const [movedItem] = sourceArr.splice(sourceIndex, 1);
        destArr.splice(destIndex, 0, movedItem);
        newState = setArray(newState, sourceContainer, sourceArr);
        newState = setArray(newState, destContainer, destArr);
      }

      logArrayIds('yourVideos', newState.yourVideos);
      logArrayIds('selects', newState.selects);
      return newState;
    });
  }, []);

  // For DragOverlay
  const allVideos = [...videoState.yourVideos, ...videoState.selects];
  const activeVideo = allVideos.find(v => v.id === activeId) || null;

  return (
    <div className="min-h-screen bg-gray-100 p-2 md:p-6">
      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragStart={e => setActiveId(e.active.id as string)}
        onDragEnd={handleDragEnd}
        onDragCancel={() => setActiveId(null)}
      >
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 grid-rows-[auto_1fr_auto] gap-2 md:gap-4 w-full max-w-screen-2xl mx-auto">
          {/* Top Row */}
          <div className="col-span-1 md:col-span-1 lg:col-span-1 row-span-1 flex items-center justify-center min-h-[64px] md:h-24">
            <DropboxAuth
              onAuthChange={setIsDropboxAuthenticated}
              highlight={getStepStatus('connect') === 'next'}
              state={getStepStatus('connect')}
            />
          </div>
          <button
            className={`col-span-1 md:col-span-1 lg:col-span-1 row-span-1 flex items-center justify-center min-h-[64px] md:h-24 font-black text-xl md:text-2xl transition-all focus:outline-none rounded-lg w-full h-full
              ${getStepStatus('addVideos') === 'next' ? 'bg-yellow-300 text-yellow-900 animate-pulse' : getStepStatus('addVideos') === 'complete' ? 'bg-green-400 text-white' : 'bg-gray-300 text-gray-700'}
              ${!isDropboxAuthenticated && getStepStatus('addVideos') !== 'next' ? 'opacity-50 pointer-events-none' : 'hover:bg-blue-200 cursor-pointer'}`}
            onClick={handleAddVideosClick}
            disabled={!isDropboxAuthenticated && getStepStatus('addVideos') !== 'next'}
            type="button"
          >
            ADD VIDEOS
          </button>
          <div className={`col-span-1 md:col-span-2 lg:col-span-2 row-span-1 flex items-center justify-center min-h-[64px] md:h-24 font-black text-3xl md:text-5xl lg:text-6xl text-center transition-opacity bg-gray-300 rounded-lg`}>
            ADD TITLE HERE
          </div>
          {/* Middle Row: DnD Panels */}
          <div className={`col-span-1 md:col-span-1 lg:col-span-2 row-span-1 bg-gray-300 rounded-lg p-2 md:p-4 transition-opacity ${!isDropboxAuthenticated ? 'opacity-50 pointer-events-none' : ''}`}>
            <div className="font-black text-lg md:text-xl mb-2">YOUR VIDEOS</div>
            <div className="min-h-[128px] md:h-64 bg-gray-200 rounded overflow-y-auto p-2">
              <SortableContext items={videoState.yourVideos.map(v => v.id)} strategy={rectSortingStrategy}>
                <DndKitVideoGrid
                  videos={videoState.yourVideos}
                  onReorder={newOrder => setVideoState(s => ({ ...s, yourVideos: newOrder }))}
                  gridId="yourVideos"
                  emptyMessage={isFetchingVideos ? 'Loading videos...' : error ? error : 'No videos loaded.'}
                />
              </SortableContext>
            </div>
          </div>
          <div className={`col-span-1 md:col-span-1 lg:col-span-2 row-span-1 bg-gray-300 rounded-lg p-2 md:p-4 transition-opacity ${!isDropboxAuthenticated ? 'opacity-50 pointer-events-none' : ''}`}>
            <div className="font-black text-lg md:text-xl mb-2">SELECTS</div>
            <div className="min-h-[128px] md:h-64 bg-gray-200 rounded overflow-y-auto p-2">
              <SortableContext items={videoState.selects.map(v => v.id)} strategy={rectSortingStrategy}>
                <DndKitVideoGrid
                  videos={videoState.selects}
                  onReorder={newOrder => setVideoState(s => ({ ...s, selects: newOrder }))}
                  gridId="selects"
                  emptyMessage="No videos selected. Drag videos here."
                />
              </SortableContext>
            </div>
          </div>
          {/* Bottom Row */}
          <div className={`col-span-1 md:col-span-1 lg:col-span-2 row-span-1 bg-gray-300 rounded-lg flex items-center justify-center min-h-[48px] md:h-20 font-black text-2xl md:text-3xl transition-opacity ${!isDropboxAuthenticated ? 'opacity-50 pointer-events-none' : ''}`}>THEME (MENU)</div>
          <div className={`col-span-1 md:col-span-1 lg:col-span-2 row-span-1 bg-gray-300 rounded-lg flex items-center justify-center min-h-[48px] md:h-20 font-black text-2xl md:text-3xl transition-opacity ${!isDropboxAuthenticated ? 'opacity-50 pointer-events-none' : ''}`}>PREVIEW REEL</div>
        </div>
        <DragOverlay>
          {activeVideo ? (
            <div className="w-32">
              <img
                src={activeVideo.thumbnailUrl}
                alt={activeVideo.name}
                className="w-full aspect-video object-cover rounded"
              />
              <div className="truncate text-xs text-center mt-1 w-full" title={activeVideo.name}>{activeVideo.name}</div>
            </div>
          ) : null}
        </DragOverlay>
      </DndContext>
      {showFolderBrowser && (
        <FolderBrowser
          onFolderSelect={path => {
            setFolderPath(path);
            setShowFolderBrowser(false);
            fetchVideos(path);
          }}
          onClose={() => setShowFolderBrowser(false)}
          initialPath={folderPath}
        />
      )}
    </div>
  );
}
